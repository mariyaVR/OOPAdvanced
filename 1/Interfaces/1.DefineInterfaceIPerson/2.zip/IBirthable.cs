﻿namespace _1.DefineInterfaceIPerson
{
    internal interface IBirthable
    {
        string Birthdate { get; }
    }
}