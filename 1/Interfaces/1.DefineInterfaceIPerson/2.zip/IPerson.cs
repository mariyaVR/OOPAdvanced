﻿namespace _1.DefineInterfaceIPerson
{
    internal interface IPerson
    {
        string Name { get; }
        int Age { get; }
    }
}