﻿namespace _1.DefineInterfaceIPerson
{
    internal interface IIdentifiable
    {
        string ID { get; }
    }
}