﻿
using System;

class Startup
{
    private static void Main(string[] args)
    {
        string input = Console.ReadLine();
        Type typeRank = typeof(CardRank);
        Type typeSuit = typeof(CardSuit);
        object[] rankAttributes = typeRank.GetCustomAttributes(false);
        object[] suitAttributes = typeSuit.GetCustomAttributes(false);
        switch (input)
        {
            case "Rank":
                foreach (TypeAttribute attr in rankAttributes)
                {
                    Console.WriteLine($"Type = {attr.Type}, Description = {attr.Description}");
                }
                break;
            case "Suit":
                foreach (TypeAttribute attr in suitAttributes)
                {
                    Console.WriteLine($"Type = {attr.Type}, Description = {attr.Description}");
                }
                break;
        }
    }
}