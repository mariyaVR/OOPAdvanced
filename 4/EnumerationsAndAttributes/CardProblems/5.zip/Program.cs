﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string rank = Console.ReadLine().Trim();
        string suit = Console.ReadLine().Trim();
        string rankOther = Console.ReadLine().Trim();
        string suitOther = Console.ReadLine().Trim();

        Card card = new Card(rank, suit);
        Card OtherCard = new Card(rankOther, suitOther);

        int result = card.CompareTo(OtherCard);

        if (result < 0)
        {
            Console.WriteLine(card.ToString());
        }
        else
        {
            Console.WriteLine(OtherCard.ToString());
        }
    }
}