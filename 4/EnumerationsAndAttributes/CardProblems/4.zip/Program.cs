﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string rank = Console.ReadLine().Trim();
        string suit = Console.ReadLine().Trim();

        Card card = new Card(rank, suit);

        Console.WriteLine(card.ToString());
    }
}