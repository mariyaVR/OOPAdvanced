﻿namespace KingsGambitExtended.Interfaces
{
    public interface INameable
    {
        string Name { get; }
    }
}