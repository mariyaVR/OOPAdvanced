﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.GenericBox
{
    public class Box<T>
    {
        private T value;

        public Box()
            : this(default(T))
        {

        }

        public Box(T value)
        {
            this.Value = value;
        }
        

        public T Value { get; set; }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            result.Append(Value.GetType().FullName);
            return result.ToString();
        }
    }
}
